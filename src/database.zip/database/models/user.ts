import {Table, Column ,Model, DataType } from 'sequelize-typescript'

@Table({
    tableName : 'Users',
    modelName : 'UserModel',
})

class UserModel extends Model{
    @Column({
        type : DataType.STRING(25),
        allowNull : false
    })
    declare actionBy : string;
}

export default UserModel